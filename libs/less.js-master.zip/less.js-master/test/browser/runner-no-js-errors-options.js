var less = {logLevel: 4};

less.strictUnits = true;
less.javascriptEnabled = false;
